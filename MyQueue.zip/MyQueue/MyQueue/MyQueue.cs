﻿using System;

namespace MyQueue
{
    public class MyQueue
    {
        #region Fields

        int[] array; // Массив с элементами

        int currentOut; // Индекс начального элемента.
        int currentIn; // Индекс конечного элемента.

        int length = 0; // Текущее количество элементов в очереди

        #endregion

        #region ctor

        // length - размер очереди (т.е. размер массива)
        public MyQueue(int length)
        {
            array = new int[length];
        }

        #endregion

        #region Public methods

        // Извлечение элемента из очереди.
        public int Pop()
        {
            // Проверяем, можно ли что-либо достать из очереди.
            // Если нет, возвращаем -1 без исключений, чтобы программа просто не падала.
            if (length == 0)
                return -1;

            // Достаём первый элемент.
            int local = array[currentOut];
            // Обнуляем первый элемент.
            array[currentOut] = 0;
            // Изменяем индекс начала элементов в массиве.
            currentOut = currentOut + 1;
            // Убавляем количество элементов.
            length--;
            return local;
        }

        // Добавление элемента в очередь.
        public void Push(int item)
        {
            // Проверяем ёмкость массива
            // Если недостаточно места, не выбрасываем исключения
            if (length == array.Length || currentIn >= array.Length)
                return;

            // Устанавливаем последний элемент.
            array[currentIn] = item;
            // Изменяем индекс конца массива.
            currentIn = currentIn + 1;
            // Прибавляем количество элементов.
            length++;
        }

        // Получить состояние очереди
        public string Values()
        {
            string str = string.Empty;
            if (currentIn == currentOut)
                return "Пусто";

            for (int i = currentOut; i < currentIn; i++)
                str += array[i] + " ";

            return str;
        }

        #endregion
    }
}