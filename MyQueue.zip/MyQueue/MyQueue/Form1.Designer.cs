﻿namespace MyQueue
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxLength = new System.Windows.Forms.TextBox();
            this.textBoxQueueDisplay = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonCreateQueue = new System.Windows.Forms.Button();
            this.textBoxPush = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonPush = new System.Windows.Forms.Button();
            this.buttonPop = new System.Windows.Forms.Button();
            this.textBoxPop = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите размер очереди:";
            // 
            // textBoxLength
            // 
            this.textBoxLength.Location = new System.Drawing.Point(29, 44);
            this.textBoxLength.Name = "textBoxLength";
            this.textBoxLength.Size = new System.Drawing.Size(145, 23);
            this.textBoxLength.TabIndex = 1;
            // 
            // textBoxQueueDisplay
            // 
            this.textBoxQueueDisplay.Location = new System.Drawing.Point(239, 44);
            this.textBoxQueueDisplay.Name = "textBoxQueueDisplay";
            this.textBoxQueueDisplay.ReadOnly = true;
            this.textBoxQueueDisplay.Size = new System.Drawing.Size(319, 23);
            this.textBoxQueueDisplay.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(239, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Состояние очереди:";
            // 
            // buttonCreateQueue
            // 
            this.buttonCreateQueue.Location = new System.Drawing.Point(29, 73);
            this.buttonCreateQueue.Name = "buttonCreateQueue";
            this.buttonCreateQueue.Size = new System.Drawing.Size(145, 23);
            this.buttonCreateQueue.TabIndex = 4;
            this.buttonCreateQueue.Text = "Создать очередь";
            this.buttonCreateQueue.UseVisualStyleBackColor = true;
            this.buttonCreateQueue.Click += new System.EventHandler(this.buttonCreateQueue_Click);
            // 
            // textBoxPush
            // 
            this.textBoxPush.Location = new System.Drawing.Point(29, 136);
            this.textBoxPush.Name = "textBoxPush";
            this.textBoxPush.Size = new System.Drawing.Size(145, 23);
            this.textBoxPush.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Введите элемент:";
            // 
            // buttonPush
            // 
            this.buttonPush.Location = new System.Drawing.Point(29, 165);
            this.buttonPush.Name = "buttonPush";
            this.buttonPush.Size = new System.Drawing.Size(145, 23);
            this.buttonPush.TabIndex = 7;
            this.buttonPush.Text = "Добавить";
            this.buttonPush.UseVisualStyleBackColor = true;
            this.buttonPush.Click += new System.EventHandler(this.buttonPush_Click);
            // 
            // buttonPop
            // 
            this.buttonPop.Location = new System.Drawing.Point(29, 245);
            this.buttonPop.Name = "buttonPop";
            this.buttonPop.Size = new System.Drawing.Size(145, 23);
            this.buttonPop.TabIndex = 10;
            this.buttonPop.Text = "Извлечь";
            this.buttonPop.UseVisualStyleBackColor = true;
            this.buttonPop.Click += new System.EventHandler(this.buttonPop_Click);
            // 
            // textBoxPop
            // 
            this.textBoxPop.Location = new System.Drawing.Point(29, 216);
            this.textBoxPop.Name = "textBoxPop";
            this.textBoxPop.ReadOnly = true;
            this.textBoxPop.Size = new System.Drawing.Size(145, 23);
            this.textBoxPop.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 304);
            this.Controls.Add(this.buttonPop);
            this.Controls.Add(this.textBoxPop);
            this.Controls.Add(this.buttonPush);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxPush);
            this.Controls.Add(this.buttonCreateQueue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxQueueDisplay);
            this.Controls.Add(this.textBoxLength);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "MyQueue";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox textBoxLength;
        private TextBox textBoxQueueDisplay;
        private Label label2;
        private Button buttonCreateQueue;
        private TextBox textBoxPush;
        private Label label3;
        private Button buttonPush;
        private Button buttonPop;
        private TextBox textBoxPop;
    }
}